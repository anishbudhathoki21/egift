const express=require('express');
const Gift=require('../models/gift');
const auth=require('../auth');

const router = express.Router();

router.route('/')
.get((req,res,next)=>
{
    Gift.find({})
    .then((gifts)=>
    {
        res.json(gifts);
    })
    .catch(next);
})
.post((req,res,next)=>
{
    Gift.create(req.body)
    .then((gift)=>
    {
        res.statusCode=201;
        res.json(gift);
    })
    .catch(next);
})
.put((req,res)=>
{
    res.statusCode=405;
    res.json({message:"Method not allowed"});

})
.delete(auth.verifyAdmin,(req,res,next)=>
{
    Gift.deleteMany({})
    .then((reply)=>
    {
        res.json(reply);
    })
    .catch(next)
});

router.route('/:id')
.get((req,res,next)=>
{
    Gift.findById(req,params.id)
    .then((gift)=>
    {
        res.json(gift);
    })
    .catch((err)=>next(err));
})

.post((req,res,next)=>
{
    res.statusCode=201;
    res.json("You cannot gift here");


})

.put((req,res,next)=>{
    Gift.findByIdAndUpdate(req.params.id,{$set:req.body}
        .then((gift)=>
        {
            res.json(gift);
        })
        .catch((err)=>next(err)));
        
})

.delete((req,res,next)=>
{
    Gift.findByIdAndDelete(req.params.id)
    .then((gift)=>
    {
        res.json(gift);
    })
    .catch((err)=>next(err));
})
module.exports=router;