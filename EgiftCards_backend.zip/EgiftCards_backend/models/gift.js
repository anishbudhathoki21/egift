const mongoose = require("mongoose");


const giftSchema= new mongoose.Schema(
    {
        giftName:
        {
            type:String,
            required:true
        },
       
        giftPrice:
        {
            type:String,
            required:true
        },
        giftPic:
        {
            type:String,
            required:true
        }

    }
)

module.exports=mongoose.model('Gifts',giftSchema);