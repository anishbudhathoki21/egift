const express = require("express");
const mongoose = require("mongoose");
const userRouter = require('./routes/users');
// const ridepostRouter = require('./routes/ridepost');
const dotenv = require('dotenv').config();
const app = express();
const cors = require ('cors');


app.options('*', cors());
app.use(cors());

app.use(express.json());
app.use(express.static(__dirname + "/public"));

mongoose.connect(process.env.URL, {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true})
    .then((db) => {
        console.log("Successfully connected to Mongodb server");    
    }, (err) => console.log(err));

    app.use('/users', userRouter);
    // app.use('/ridepost', ridepostRouter);

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.statusCode = 500;
    res.json({message: err.message});
});

app.listen(process.env.PORT, () => {
    console.log(`App is running at localhost: ${process.env.PORT}`);
});