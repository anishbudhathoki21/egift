# TaskReminder
A Task Reminder/Scheduler App created using Sqlite database and Broadcast Receivers
It contains four options for reminding about your tasks:
1.Standrad
2.Simple
3.Urgent(Alert with AlarmMAnager)
4.Notify(Notification alert)
It also provides sqlite database basic crud operations using SqliteOpenHelper and ContentValues,Cursor.<br>
<b>Enjoy and fork it.Happy Coding</b><br><br>
I am Sharing some screenshots of the app.<br><br>
<img src="https://github.com/vikashumain/TaskReminder/blob/master/Screenshot_2018-01-08-17-33-50-253_com.taskreminder.png"><br><br>
<img src="https://github.com/vikashumain/TaskReminder/blob/master/Screenshot_2018-01-08-17-34-01-566_com.taskreminder.png">

