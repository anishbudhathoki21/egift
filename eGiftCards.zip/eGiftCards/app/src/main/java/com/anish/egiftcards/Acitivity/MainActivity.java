package com.anish.egiftcards.Acitivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.Nullable;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.anish.egiftcards.API.EgiftAPI;
import com.anish.egiftcards.Model.User;
import com.anish.egiftcards.R;
import com.anish.egiftcards.Url;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    Button btnLogin;
    EditText username, password;
    TextView tvSign;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText)findViewById(R.id.etUsername);
        password = (EditText)findViewById(R.id.etPassword);
        btnLogin = (Button)findViewById(R.id.btnLogin);
        tvSign=(TextView)findViewById(R.id.tvSign);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        tvSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signUp();
            }
        });



    }

        private void login()
        {
            final String uname,psswd;
            uname=username.getText().toString();
            psswd=password.getText().toString();

            if(!uname.isEmpty() && !psswd.isEmpty())
            {
                User userLogin= new User(uname,psswd);
                EgiftAPI loginAPI= Url.getInstance().create(EgiftAPI.class);
                Call<Void> callLogin=loginAPI.login(userLogin);
                callLogin.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if(!response.isSuccessful())
                        {
                            Toast.makeText(MainActivity.this, "Username or Password donot match", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        dash();
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t)
                    {
                        Toast.makeText(MainActivity.this, "Error" + t.getLocalizedMessage(),Toast.LENGTH_SHORT).show();

                    }




                });
            }
        }
        public void dash()
        {
            Intent openDashboard= new Intent(this,DashboardActivity.class);
            startActivity(openDashboard);
        }


        public void signUp()
        {
            Intent sign= new Intent(this,SignupActivity.class);
            startActivity(sign);
        }


    }



