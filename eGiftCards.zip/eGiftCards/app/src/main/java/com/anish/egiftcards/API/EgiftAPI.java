package com.anish.egiftcards.API;

import com.anish.egiftcards.Model.User;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface EgiftAPI {

    @POST("users/signup")
    Call<Void> signup(@Body User user);

    @POST ("users/login")
    Call<Void> login (@Body User user);
}
